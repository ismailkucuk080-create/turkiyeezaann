const CACHE_NAME = 'ezan-vakti-v3';

// Sadece kendi dosyalarımızı ana önbelleğe alıyoruz.
// Yeni eklediğimiz PWA dosyalarını (manifest ve ikonlar) da buraya dahil ettik.
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

// Kurulum (Install) Aşaması
self.addEventListener('install', (e) => {
  self.skipWaiting(); // Yeni versiyonu hemen aktif et
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
        console.log("Service Worker: Dosyalar önbelleğe alınıyor.");
        return cache.addAll(ASSETS).catch(error => console.error("Cache Hatası:", error));
    })
  );
});

// Aktivasyon (Activate) Aşaması - Eski önbellekleri temizler
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => {
            console.log("Service Worker: Eski önbellek temizlendi.", k);
            return caches.delete(k);
        })
      );
    })
  );
});

// İstekleri Yakalama (Fetch) Aşaması
self.addEventListener('fetch', (e) => {
  e.respondWith(
    // Önce internetten çekmeyi dene, ağ yoksa önbellekten (cache) getir.
    fetch(e.request)
      .then((response) => {
        // Geçerli bir yanıt gelirse (ve API isteği değilse) bunu da önbelleğe kopyala
        if (!response || response.status !== 200 || response.type !== 'basic') {
          return response;
        }
        let responseToCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(e.request, responseToCache);
        });
        return response;
      })
      .catch(() => {
        // İnternet yoksa önbellekteki dosyayı döndür
        return caches.match(e.request);
      })
  );
});

// Bildirime Tıklama Olayı
self.addEventListener('notificationclick', function(event) {
  event.notification.close(); // Bildirimi kapat

  event.waitUntil(
    clients.matchAll({ type: 'window' }).then(windowClients => {
      // Eğer uygulama zaten kısımlarda açıksa, o sekmeye odaklan
      for (var i = 0; i < windowClients.length; i++) {
        var client = windowClients[i];
        if (client.url.includes('/') && 'focus' in client) {
          return client.focus();
        }
      }
      // Açık değilse yeni pencerede aç
      if (clients.openWindow) {
        return clients.openWindow('/');
      }
    })
  );
});
